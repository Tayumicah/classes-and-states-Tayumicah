This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

Run npm start to launch the server.

Edit src/App.js to complete the assignment.
