// Header.js
import React from "react";

function Header(props) {
  return <h1> I have {props.numDogs} dogs!</h1>;
}

export default Header;
